public interface Offer {
    int getDiscount(Car car);
}
