package finalpachet;

/*public class ClasaFinalDerivata extends ClasaFinal {
    public ClasaFinalDerivata (int id){
       super(id);
    }
    public final String metodaFinal(){
        return "Metoda final parinte" +id;
    }
    public  String metodaNefinal(){
        return "Metoda nefinal parinte" +id;
    }
}
*/
public class ClasaFinalDerivata extends finalpachet.ClasaFinal {

}